import { SystemProfile, Project, Skill, LogEntry, Certification, Milestone, ContactInfo } from './types';

export const systemProfile: SystemProfile = {
  name: "POOJA_SHREE_ENGINE",
  version: "v2.6-stable",
  missionStatement: "To engineer scalable, low-latency, and highly secure software architectures that bridge robust systems programming with intelligent cloud-native orchestration.",
  primaryFunctions: [
    "Full-Stack Software Engineering",
    "Distributed Systems Orchestration",
    "Network Infrastructure Security",
    "Algorithmic Problem Solving"
  ],
  currentFocus: "Architecting high-throughput serverless microservices and researching autonomous zero-trust authentication pipelines.",
  technicalInterests: [
    "Machine Learning & Deep Learning",
    "Zero-Trust Network Architectures",
    "Distributed Consensus (Raft/Paxos)",
    "Cloud Serverless Infrastructure",
    "Cybersecurity Analytics"
  ]
};

export const projects: Project[] = [
  {
    id: "aegis-net",
    name: "AegisNet: Intelligent Packet Inspection System",
    overview: "A high-performance packet sniffer and intrusion detection engine featuring real-time deep learning anomaly classification for local networks.",
    problemStatement: "Traditional signature-based network scanners fail to identify zero-day packet anomalies in real-time and severely degrade link throughput.",
    solution: "Developed an asynchronous multi-threaded packet capture engine using libpcap in C++, coupled with a lightweight sidecar TensorFlow model for high-speed packet classification.",
    technologies: ["C++", "Python", "TensorFlow", "libpcap", "gRPC", "Docker", "React"],
    responsibilities: [
      "Engineered the asynchronous ring-buffer logging module in C++ to prevent packet dropping.",
      "Integrated a gRPC streaming pipeline between the C++ packet sniffer and the Python TensorFlow service.",
      "Built a real-time web dashboard using React and Tailwind CSS for network telemetry rendering."
    ],
    impact: [
      "Achieved sub-millisecond anomaly detection latency under a peak throughput of 1.2 Gbps.",
      "Attained a 98.4% classification accuracy on benchmark IDS packet datasets with near-zero packet drop rate."
    ],
    githubLink: "https://github.com/poojashreeravichandar/aegis-net",
    dependencies: [
      { id: "dep-1", name: "Asynchronous Packet Sniffer (C++)", type: "core" },
      { id: "dep-2", name: "gRPC Streaming Model Gateway", type: "service" },
      { id: "dep-3", name: "IDS Telemetry Dashboard (React)", type: "module" }
    ]
  },
  {
    id: "nova-cloud",
    name: "NovaCloud: Multi-Region Event Orchestrator",
    overview: "A decentralized, event-driven state machine designed to coordinate serverless microservices across AWS and GCP regions dynamically.",
    problemStatement: "Standard workflow engines are tightly coupled with single-region infrastructure and exhibit significant recovery latencies during regional outages.",
    solution: "Designed a multi-master scheduler in Go that uses Raft consensus to manage workflow states, load-balancing serverless invocations dynamically based on live region metrics.",
    technologies: ["Go", "AWS Lambda", "Google Cloud Run", "Redis", "TypeScript", "Raft", "Terraform"],
    responsibilities: [
      "Implemented the Raft leader election and state machine replication logic in Go.",
      "Wrote latency-based dynamic load routing handlers to trigger region-nearest serverless containers.",
      "Configured multi-region active-active VPC peering and Redis Sentinel setups using Terraform."
    ],
    impact: [
      "Reduced average cross-region routing latency by 42% compared to standard central gateways.",
      "Ensured zero-downtime microservice execution with automated regional failovers completing in under 250ms."
    ],
    githubLink: "https://github.com/poojashreeravichandar/nova-cloud",
    dependencies: [
      { id: "dep-4", name: "Go Coordinator (Raft Core)", type: "core" },
      { id: "dep-5", name: "Multi-Region Redis Sentinel", type: "service" },
      { id: "dep-6", name: "Serverless Deployments (AWS/GCP)", type: "library" }
    ]
  },
  {
    id: "sentinel-db",
    name: "SentinelDB: Autonomous Relational Query Proxy",
    overview: "A smart database proxy that parses SQL streams, dynamically constructs optimized indices, and caches query subgraphs.",
    problemStatement: "Sudden analytical spikes inside database systems cause disk I/O bottlenecks that manual DBA indexing cannot remediate dynamically.",
    solution: "Built an intermediate SQL query parsing proxy that constructs AST representations, evaluates query costs, and runs lightweight online index recommendation algorithms.",
    technologies: ["Java", "SQL", "ANTLR", "PostgreSQL", "Spring Boot", "Redis", "Docker"],
    responsibilities: [
      "Wrote AST parsers using ANTLR to map incoming PostgreSQL query structures.",
      "Designed dynamic index-recommendation heuristics based on table cardinality and scan frequencies.",
      "Configured caching patterns using Redis to short-circuit repeated query execution plans."
    ],
    impact: [
      "Decreased analytical SQL execution latencies by up to 55% during query volume spikes.",
      "Reduced CPU utilization overhead on target PostgreSQL databases by 28% through preemptive caching."
    ],
    githubLink: "https://github.com/poojashreeravichandar/sentinel-db",
    dependencies: [
      { id: "dep-7", name: "SQL AST Parser (Java/ANTLR)", type: "core" },
      { id: "dep-8", name: "Online Recommendation Engine", type: "service" },
      { id: "dep-9", name: "Caching Proxy (Redis/Postgres)", type: "library" }
    ]
  }
];

export const skills: Skill[] = [
  // Programming Languages
  { name: "Java", status: "Operational", category: "Languages", value: 90 },
  { name: "Python", status: "Operational", category: "Languages", value: 85 },
  { name: "Go", status: "Active", category: "Languages", value: 75 },
  { name: "C++", status: "Operational", category: "Languages", value: 70 },
  { name: "TypeScript", status: "Active", category: "Languages", value: 80 },
  { name: "SQL", status: "Operational", category: "Languages", value: 85 },
  
  // Web Technologies
  { name: "ReactJS", status: "Active", category: "Web Technologies", value: 85 },
  { name: "Node.js", status: "Active", category: "Web Technologies", value: 80 },
  { name: "Tailwind CSS", status: "Active", category: "Web Technologies", value: 90 },
  { name: "Next.js", status: "Active", category: "Web Technologies", value: 75 },
  { name: "Spring Boot", status: "Active", category: "Web Technologies", value: 70 },

  // Core CS
  { name: "Problem Solving", status: "Active", category: "Core CS", value: 92 },
  { name: "Networking Protocols", status: "Active", category: "Core CS", value: 85 },
  { name: "System Design", status: "Active", category: "Core CS", value: 80 },
  { name: "Cybersecurity Basics", status: "Active", category: "Core CS", value: 75 },
  { name: "Distributed Systems", status: "Active", category: "Core CS", value: 75 },

  // Tools & Platforms
  { name: "Cloud Computing", status: "Learning", category: "Tools & Platforms", value: 80 },
  { name: "Docker & K8s", status: "Learning", category: "Tools & Platforms", value: 70 },
  { name: "AWS Services", status: "Learning", category: "Tools & Platforms", value: 75 },
  { name: "Git / GitHub", status: "Operational", category: "Tools & Platforms", value: 90 },
  { name: "Linux Systems", status: "Operational", category: "Tools & Platforms", value: 85 }
];

export const missionLogs: LogEntry[] = [
  {
    id: "intern-1",
    role: "Software Engineering Intern",
    organization: "Bosch Global Software Technologies",
    location: "Bangalore, India",
    timeline: "Jan 2025 - Jun 2025",
    type: "Internship",
    status: "Deployed",
    description: [
      "Engineered an event-driven telemetry ingestion engine in Go for Bosch's connected IoT sensor platforms.",
      "Optimized database indexing and implemented Redis cluster caching, accelerating read queries by 35%.",
      "Wrote comprehensive unit and load tests, identifying and resolving two critical race conditions in thread pools."
    ]
  },
  {
    id: "lead-1",
    role: "Technical Lead",
    organization: "Google Developer Student Clubs (GDSC)",
    location: "Dayananda Sagar University",
    timeline: "Aug 2024 - Present",
    type: "Leadership",
    status: "Active",
    description: [
      "Led a core technical committee of 15 student developers to deploy high-traffic hackathon registrations and scoring servers.",
      "Conducted 10+ hands-on technical bootcamps on Data Structures, Git, and REST API development for over 450+ campus students.",
      "Mentored project development teams, resulting in 3 teams advancing to national-level hackathon finals."
    ]
  },
  {
    id: "org-1",
    role: "Technical Coordinator",
    organization: "Computer Society of India (CSI)",
    location: "Dayananda Sagar University",
    timeline: "Jun 2023 - May 2024",
    type: "Organization",
    status: "Archived",
    description: [
      "Coordinated campus-wide programming contests, managing dynamic automated compilers and custom sandbox execution runtimes.",
      "Designed curriculum and led interactive workshops on Bash scripting, GNU tools, and standard automation techniques."
    ]
  },
  {
    id: "affil-1",
    role: "Professional Member",
    organization: "IEEE Computer Society Student Branch",
    location: "Dayananda Sagar University",
    timeline: "Jan 2023 - Present",
    type: "Affiliation",
    status: "Active",
    description: [
      "Actively participated in research seminars focused on zero-trust architectures and lightweight machine learning models.",
      "Contributed to local research teams modeling low-power IoT networks and high-frequency sensor streams."
    ]
  }
];

export const certifications: Certification[] = [
  {
    id: "cert-aws",
    name: "AWS Certified Solutions Architect – Associate",
    issuer: "Amazon Web Services (AWS)",
    date: "Dec 2024",
    status: "Verified",
    verificationId: "AWS-ASA-9943F",
    skillsUnlocked: ["Cloud Architecture", "Serverless Orchestration", "IAM & VPC Configuration", "Dynamic Scaling"]
  },
  {
    id: "cert-java",
    name: "Oracle Certified Associate, Java SE 8 Programmer",
    issuer: "Oracle",
    date: "Jul 2024",
    status: "Verified",
    verificationId: "OCA-JAVA-SE8-112B",
    skillsUnlocked: ["Object-Oriented Design", "Multithreading Basics", "Exception Architectures", "Memory Management"]
  },
  {
    id: "cert-gcp",
    name: "Associate Cloud Engineer",
    issuer: "Google Cloud Platform (GCP)",
    date: "In Progress",
    status: "In Progress",
    skillsUnlocked: ["Google Kubernetes Engine (GKE)", "Compute Engine Admin", "VPC Networking", "IAM Roles"]
  }
];

export const milestones: Milestone[] = [
  {
    version: "v1.0",
    title: "Student Core Node",
    date: "Aug 2022",
    description: "Initialized computer science studies. Mastered core Data Structures, Algorithms, object-oriented Java, and UNIX systems.",
    status: "released"
  },
  {
    version: "v1.5",
    title: "Technical Explorer Module",
    date: "Sep 2023",
    description: "Began building real-world network and web architectures. Joined campus tech clubs (CSI/GDSC) and began competitive programming.",
    status: "released"
  },
  {
    version: "v2.0",
    title: "Orchestrator Deployed",
    date: "Jan 2025",
    description: "Secured Bosch SE internship. Designed real-time message brokers and deployed full-stack microservices on multi-region clouds.",
    status: "released"
  },
  {
    version: "v2.5",
    title: "Active Build",
    date: "Present",
    description: "Integrating deep learning systems with packet inspection pipelines. Actively seeking Software Engineering roles.",
    status: "active"
  },
  {
    version: "v3.0",
    title: "Enterprise Deploy",
    date: "Future",
    description: "Deploying enterprise-grade microservice orchestration, secure authentication frameworks, and contributing to open-source software networks.",
    status: "scheduled"
  }
];

export const contactInfo: ContactInfo = {
  email: "poojashreeravichandar2496@gmail.com",
  phone: "+91 91507 88151",
  location: "Bangalore, India",
  github: "https://github.com/poojashreeravichandar",
  linkedin: "https://linkedin.com/in/poojashreeravichandar",
  leetcode: "https://leetcode.com/poojashreeravichandar"
};
